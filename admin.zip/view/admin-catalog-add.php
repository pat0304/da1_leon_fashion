<form action="" method="post" enctype="multipart/form-data">

<div class="product-box">
    <div class="btn-box">
        <h2>Thêm danh mục </h2>
        <input type="submit" class="btn-add" name="submit" value="Thêm">
    </div>
</div>
<div class="container">     
    <div class="mb-3 mt-2">
        <label for="disabledTextInput" class="form-label"> <h4>Tên Danh Mục</h4></label>
        <input type="text" id="disabledTextInput" class="form-control" name="name" placeholder="Tên danh mục mới">
    </div>
</div>
</form>