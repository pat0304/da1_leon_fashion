<form action="" method="post" enctype="multipart/form-data">
<div class="product-box">
                    <div class="btn-box">
                        <h2>Thêm voucher </h2>
                        <input type="submit" class="btn-add" name="submit" value="Thêm">
                    </div>
                </div>
                <div class="container">     
                    <div class="mb-3 mt-2">
                        <label for="disabledTextInput" class="form-label"> <h5>Mã Voucher</h5></label>
                        <input type="text" id="disabledTextInput" class="form-control" name="code" placeholder="">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="disabledTextInput" class="form-label"> <h5>Giá trị</h5></label>
                        <input type="number" id="disabledTextInput" class="form-control" name="value" placeholder="">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="disabledTextInput" class="form-label"> <h5>Số lượng</h5></label>
                        <input type="number" id="disabledTextInput" class="form-control" name="sl" placeholder="">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="disabledTextInput" class="form-label"> <h5>Ngày bắt đầu</h5></label>
                        <input type="date" id="disabledTextInput" class="form-control" name="ngay_ap_dung" placeholder="">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="disabledTextInput" class="form-label"> <h5>Ngày kết thúc</h5></label>
                        <input type="date" id="disabledTextInput" class="form-control" name="ngay_ket_thuc" placeholder="">
                    </div>
                    
                </div>
            </form>