<div id="trade" style="margin-top: 150px">
    <h2>Tìm kiếm</h2>
    <div class="note"><?= $note ?></div>
    <div class="products">
        <?php show_products($searchOutput);?>
    </div>
</div>